package com.great.quiz;

public class QuestionLibrary {

    private String mQuestions [] = {
            "Berikut ini merupakan penggunaan atau fungsi tanda titik, kecuali...",
            "Kesalahan penulisan huruf besar terdapat pada kalimat...",
            "Berikut ini merupakan contoh penggunaan tanda hubung yang benar, kecuali...",
            "Penulisan kata bilangan yang sesuai dengan EYD terdapat pada kalimat berikut",
            "Penulisan singkatan di bawah ini yang salah adalah"
    };

    private String mChoices [][]  = {
                    {"Mengakhiri kalimat yang bukan pertanyaan atau seruan",
                    "Diletakkan pada akhir singkatan nama atau gelar",
                    "Memisahkan anak kalimat dan induk kalimat",
                    "Memisahkan angka, jam, menit, dan detik untuk menunjukkan waktu"
                    },
                    {"Dea mengajar di sekolah dua kali seminggu",
                    "Paman suka membaca surat kabar Analisa",
                    "Siang ini Banu akan bertemu dengan Tika",
                    "Ayah membeli pisang ambon untuk kakek"
                    },
                    {"se-Jawa Barat",
                    "memPHK-kan",
                    "Tahun 90-an",
                    "Anak-anak"
                     },
                     {"Tahun ini negara Indonesia merayakan hari jadi yang ke-70.",
                    "Anaknya dapat mencapai juara ke tiga.",
                    "Pada hari yang ke-tiga anak diperiksa lagi darahnya.",
                    "Mahasiswa yang masa studinya pada saat ini berada pada semester ke IX mendapat peringatan"
                     },
                    {"ABRI", "UNNES", "Posyandu", "Siskamling"}
    };

    private String mCorrectAnswer [] = {
            "Memisahkan anak kalimat dan induk kalimat",
            "Ayah membeli pisang ambon untuk kakek",
            "memPHK-kan",
            "Tahun ini negara Indonesia merayakan hari jadi yang ke-70.",
            "UNNES"
    };

    public String getQuestion(int a) {
        String question = mQuestions[a];
        return question;
    }

    public String getChoice1(int a) {
        String choice0 = mChoices[a][0];
        return choice0;
    }

    public String getChoice2(int a) {
        String choice1 = mChoices[a][1];
        return choice1;
    }

    public String getChoice3(int a) {
        String choice2 = mChoices[a][2];
        return choice2;
    }

    public String getChoice4(int a) {
        String choice3 = mChoices[a][3];
        return choice3;
    }

    public String getCorrectAnswer(int a) {
        String answer = mCorrectAnswer[a];
        return answer;
    }
}
